﻿//
// Created by Lenovo on 24-7-15.
//

// You may need to build the project (run Qt uic code generator) to get "ui_Convert.h" resolved
#include "convert.h"
#include "ui_Convert.h"
#include<stack>


Convert::Convert(QWidget *parent) :
        QWidget(parent), ui(new Ui::Convert) {
    ui->setupUi(this);

    connect(ui->pushButton, &QPushButton::clicked, this, &Convert::convertAndDisplay);
}

Convert::~Convert() {
    delete ui;
}

void Convert::convertAndDisplay() {
    QString beforeText = ui->lineEdit->text();
    QString afterText = ui->lineEdit_2->text();
    QString numberText = ui->lineEditNumber->text();

    const int MAX_LENGTH = 15; // Define the maximum allowed length of the input number

    // Check if the input exceeds the maximum allowed length
    if (numberText.length() > MAX_LENGTH) {
        ui->outputLineEdit->setText("输入的数字过长，请输入较短的数字。");
        return; // Return early to avoid proceeding with the conversion
    }
    QString convertedNumber = numberToTraditionalChinese(numberText);
    QString result = beforeText + convertedNumber + afterText;

    ui->outputLineEdit->setText(result);
}

QString Convert::numberToTraditionalChinese(const QString& numStr) {
    QStringList numMap;
    numMap << QStringLiteral("零") << QStringLiteral("壹") << QStringLiteral("贰") << QStringLiteral("叁") << QStringLiteral("肆")
           << QStringLiteral("伍") << QStringLiteral("陆") << QStringLiteral("柒") << QStringLiteral("捌") << QStringLiteral("玖");
    QStringList units;
    units << QStringLiteral("元") << QStringLiteral("拾") << QStringLiteral("佰") << QStringLiteral("仟") << QStringLiteral("")
          << QStringLiteral("万") << QStringLiteral("亿");
    QStringList smallUnits;
    smallUnits << QStringLiteral("角") << QStringLiteral("分");

    QString result;
    bool ok;
    long long yuan = numStr.section('.', 0, 0).toLongLong(&ok); // 整数部分
    long long jiaoFen = (numStr.section('.', 1, 1).left(2) + "00").left(2).toLongLong(&ok); // 小数部分，四舍五入

    // 处理整数部分
    int unitIndex = 0;
    while (yuan > 0)
    {
        int digit = yuan % 10;
        if (digit > 0)
        {
            result = numMap[digit] + units[unitIndex % 4] + ((unitIndex % 4 == 0 && unitIndex > 0) ? units[4 + unitIndex / 4] : "") + result;
        }
        else if (!result.isEmpty() && result.front() != QStringLiteral("零"))
        {
            result = QStringLiteral("零") + result;
        }
        yuan /= 10;
        ++unitIndex;
    }

    if (result.isEmpty()) result = QStringLiteral("零元"); // 处理0元的情况
    else result += "";

    // 处理小数部分
    if (jiaoFen == 0) result += QStringLiteral("整");
    else {
        if (jiaoFen / 10 > 0) result += numMap[jiaoFen / 10] + smallUnits[0];
        if (jiaoFen % 10 > 0) result += numMap[jiaoFen % 10] + smallUnits[1];
    }

    return result;
}