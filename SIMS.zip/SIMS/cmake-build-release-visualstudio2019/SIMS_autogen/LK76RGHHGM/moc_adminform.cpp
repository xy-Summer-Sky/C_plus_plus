/****************************************************************************
** Meta object code from reading C++ file 'adminform.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../includes/form/adminform.h"
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'adminform.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSSystemUiSCOPEAdminFormENDCLASS_t {};
constexpr auto qt_meta_stringdata_CLASSSystemUiSCOPEAdminFormENDCLASS = QtMocHelpers::stringData(
    "SystemUi::AdminForm",
    "onSaveStudent",
    "",
    "onQueryStudent",
    "onDeleteStudent",
    "onUpdateStudent",
    "onAddCourseToStudent",
    "onRemoveCourseFromStudent",
    "onAddCourse",
    "onUpdateCourse",
    "onDeleteCourse",
    "onViewCourses",
    "addCourseToStudent",
    "removeCourseFromStudent",
    "onGenerateReport",
    "displayError",
    "errorMessage",
    "displaySuccessMessage",
    "successMessage"
);
#else  // !QT_MOC_HAS_STRINGDATA
#error "qtmochelpers.h not found or too old."
#endif // !QT_MOC_HAS_STRINGDATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSSystemUiSCOPEAdminFormENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  104,    2, 0x0a,    1 /* Public */,
       3,    0,  105,    2, 0x0a,    2 /* Public */,
       4,    0,  106,    2, 0x0a,    3 /* Public */,
       5,    0,  107,    2, 0x0a,    4 /* Public */,
       6,    0,  108,    2, 0x0a,    5 /* Public */,
       7,    0,  109,    2, 0x0a,    6 /* Public */,
       8,    0,  110,    2, 0x0a,    7 /* Public */,
       9,    0,  111,    2, 0x0a,    8 /* Public */,
      10,    0,  112,    2, 0x0a,    9 /* Public */,
      11,    0,  113,    2, 0x0a,   10 /* Public */,
      12,    0,  114,    2, 0x0a,   11 /* Public */,
      13,    0,  115,    2, 0x0a,   12 /* Public */,
      14,    0,  116,    2, 0x0a,   13 /* Public */,
      15,    1,  117,    2, 0x0a,   14 /* Public */,
      17,    1,  120,    2, 0x0a,   16 /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   16,
    QMetaType::Void, QMetaType::QString,   18,

       0        // eod
};

Q_CONSTINIT const QMetaObject SystemUi::AdminForm::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSSystemUiSCOPEAdminFormENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSSystemUiSCOPEAdminFormENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSSystemUiSCOPEAdminFormENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<AdminForm, std::true_type>,
        // method 'onSaveStudent'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onQueryStudent'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onDeleteStudent'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onUpdateStudent'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onAddCourseToStudent'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onRemoveCourseFromStudent'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onAddCourse'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onUpdateCourse'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onDeleteCourse'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onViewCourses'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'addCourseToStudent'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'removeCourseFromStudent'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onGenerateReport'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'displayError'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'displaySuccessMessage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>
    >,
    nullptr
} };

void SystemUi::AdminForm::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<AdminForm *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->onSaveStudent(); break;
        case 1: _t->onQueryStudent(); break;
        case 2: _t->onDeleteStudent(); break;
        case 3: _t->onUpdateStudent(); break;
        case 4: _t->onAddCourseToStudent(); break;
        case 5: _t->onRemoveCourseFromStudent(); break;
        case 6: _t->onAddCourse(); break;
        case 7: _t->onUpdateCourse(); break;
        case 8: _t->onDeleteCourse(); break;
        case 9: _t->onViewCourses(); break;
        case 10: _t->addCourseToStudent(); break;
        case 11: _t->removeCourseFromStudent(); break;
        case 12: _t->onGenerateReport(); break;
        case 13: _t->displayError((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 14: _t->displaySuccessMessage((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject *SystemUi::AdminForm::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SystemUi::AdminForm::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSSystemUiSCOPEAdminFormENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int SystemUi::AdminForm::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 15;
    }
    return _id;
}
QT_WARNING_POP
